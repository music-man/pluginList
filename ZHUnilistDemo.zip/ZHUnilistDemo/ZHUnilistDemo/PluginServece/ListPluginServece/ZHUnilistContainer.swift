//
//  ZHUnilist.swift
//  ZHList
//
//  Created by liuweimin on 2023/6/27.
//

import Foundation
import UIKit
import IGListKit

class ZHUnilistContainer: UIViewController {
    var config: ZHUnilistContainerConfig?
    var manager = ZHUniPluginManager()
    
    lazy var adapter: ListAdapter = {
        adapter = ListAdapter(updater: ListAdapterUpdater(), viewController: self, workingRangeSize: 2)
        return adapter
    }()
    
    var commonAblity: UniCommonAblity? {
        didSet {
            loadCommonPlugin()
        }
    }
    
    // 加载通用功能
    func loadCommonPlugin() {
        // 添加通用插件
        guard let commonAblity = commonAblity else {
            return
        }
        // 根据配置添加功能
        if commonAblity.gfAblity {
            if manager.addPlugin(key: "CommonGFPlugin", plugin: CommonGFPlugin()) {
                print("成功添加CommonGFPlugin")
            }
        }
    }
    
    func addPlugin(key: String, plugin: ZHUniPluginProtocol) -> Bool {
        return manager.addPlugin(key: key, plugin: plugin)
    }
    
    func addPlugins(plugins: [ZHUniPluginProtocol]) -> Bool {
        return manager.addPlugins(plugins: plugins)
    }
        
    func removePlugin(key: String, plugin: ZHUniPluginProtocol) {
        manager.removePlugin(key: key, plugin: plugin)
    }
    
    func reloadList() {
        // 刷新列表
        collectionView.reloadData()
    }

    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSizeMake(UIScreen.main.bounds.size.width - 20, 120)
        layout.minimumLineSpacing = 5
        
        let collectionV = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionV.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "cell")
        
        collectionV.backgroundColor = UIColor.red
        return collectionV
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        setAdapter()
        manager.viewDidLoad()
        collectionView.frame = view.bounds
        view.addSubview(collectionView)
    }
    
    func setAdapter() {
        adapter.collectionView = collectionView
        adapter.dataSource = self
        adapter.scrollViewDelegate = self
        adapter.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        manager.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        manager.viewDidAppear(animated)
    }
}

struct UniCommonAblity {
    var zaAblity = false
    var gfAblity = false
    var autoPlayAblity = false
}

extension ZHUnilistContainer: ListAdapterDelegate {
    func listAdapter(_ listAdapter: ListAdapter, willDisplay object: Any, at index: Int) {
        config?.delegate.listAdapter(ZHUniListAdapterBox(adapter: listAdapter), willDisplay: object, at: index)
    }

    func listAdapter(_ listAdapter: ListAdapter, didEndDisplaying object: Any, at index: Int) {
        config?.delegate.listAdapter(ZHUniListAdapterBox(adapter: listAdapter), willDisplay: object, at: index)
    }
}

class ZHUniModel: NSObject, ListDiffable {
    var oriObject: ZHUniListDiffable
    
    init(object: ZHUniListDiffable) {
        self.oriObject = object
    }
    
    func diffIdentifier() -> NSObjectProtocol {
        return oriObject.zhdiffIdentifier()
    }
    
    func isEqual(toDiffableObject object: ListDiffable?) -> Bool {
        self === object
    }
}

extension ZHUnilistContainer: UIScrollViewDelegate, ListAdapterDataSource {
    func objects(for listAdapter: ListAdapter) -> [ListDiffable] {
        if let objects = config?.dataSource.objects(for: ZHUniListAdapterBox(adapter: listAdapter)) as? [ZHUniListDiffable] {
            var newObjects = [ListDiffable]()
            for object in objects {
                newObjects.append(ZHUniModel.init(object: object))
            }
            return newObjects
        } else {
            return [ListDiffable]()
        }
    }
    
    func listAdapter(_ listAdapter: ListAdapter, sectionControllerFor object: Any) -> ListSectionController {
        if let sectionController = config?.dataSource.listAdapter(ZHUniListAdapterBox(adapter: listAdapter), sectionControllerFor: object) {
            return sectionController
        } else {
            return ListSectionController()
        }
    }
    
    func emptyView(for listAdapter: ListAdapter) -> UIView? {
        return config?.dataSource.emptyView(for: ZHUniListAdapterBox(adapter: listAdapter))
    }
}

class ZHUnilistContainerConfig: NSObject {
    var dataSource: ZHUniListAdapterDataSource
    var delegate: ZHUniListAdapterDelegate
    
    init(dataSource: ZHUniListAdapterDataSource, delegate: ZHUniListAdapterDelegate) {
        self.dataSource = dataSource
        self.delegate = delegate
    }
}

class ZHUnilistContainerFactory: NSObject {
    static func createUnilistContainer(config: ZHUnilistContainerConfig) -> ZHUnilistContainer {
        let container = ZHUnilistContainer()
        container.config = config
        return container
    }
}

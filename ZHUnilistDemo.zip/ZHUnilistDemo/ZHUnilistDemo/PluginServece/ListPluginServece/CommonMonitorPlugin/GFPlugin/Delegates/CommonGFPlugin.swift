//
//  CommonGFPlugin.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/6/27.
//

import Foundation

class CommonGFPlugin: NSObject, ZHUniPluginProtocol {
    func pluginIdentifier() -> String {
        return "UniCommonGFPlugin"
    }
    
    override init() {
        super.init()
    }
    
}

extension CommonGFPlugin: ZHUniPluginLifeCircleProtocol {
    func containerViewDidLoad() {
        print("CommonGFPlugin开始工作")
    }
    
    func containerViewWillAppear(_ animated: Bool) {
//        print("CommonGFPlugin列表容器viewWillAppear")
    }
}

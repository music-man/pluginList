//
//  ZHUnilistProtocol.swift
//  ZHList
//
//  Created by liuweimin on 2023/6/27.
//

import Foundation
import UIKit
import IGListKit

// 列表协议
protocol ZHUniListDiffable {
    func zhdiffIdentifier() -> NSObjectProtocol
    func zhisEqualToDiffableObject(object: ZHUniListDiffable) -> Bool
}

// 生命周期
@objc protocol ZHUniPluginLifeCircleProtocol {
    @objc optional func containerViewDidLoad()
    @objc optional func containerViewWillAppear(_ animated: Bool)
    @objc optional func containerViewDidAppear(_ animated: Bool)
    @objc optional func containerViewWillDisappear(_ animated: Bool)
    @objc optional func containerViewDidDisappear(_ animated: Bool)
}

// ZHListAdapter
protocol ZHUniListAdapterDataSource {
    func objects(for listAdapter: ZHUniListAdapterBox) -> [ZHUniListDiffable]
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, sectionControllerFor object: Any) -> ZHUniSectionController
    func emptyView(for listAdapter: ZHUniListAdapterBox) -> UIView?
}

protocol ZHUniListAdapterDelegate {
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, willDisplay object: Any, at index: Int)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didEndDisplaying object: Any, at index: Int)
}

protocol ZHUniListAdapterPerformanceDelegate {
    func listAdapterWillCallDequeueCell(_ listAdapter: ZHUniListAdapterBox)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox)
    func listAdapterWillCallDisplayCell(_ listAdapter: ZHUniListAdapterBox)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didCallDisplay cell: UICollectionViewCell, on sectionController: ListSectionController, at index: Int)
    func listAdapterWillCallEndDisplayCell(_ listAdapter: ZHUniListAdapterBox)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didCallEndDisplay cell: UICollectionViewCell, on sectionController: ListSectionController, at index: Int)
    func listAdapterWillCallSize(_ listAdapter: ZHUniListAdapterBox)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didCallSizeOn sectionController: ListSectionController, at index: Int)
    func listAdapterWillCallScroll(_ listAdapter: ZHUniListAdapterBox)
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didCallScroll scrollView: UIScrollView)
}



//
//  ZHUniListKitApi.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/7/14.
//

import Foundation
import IGListKit

// 装adapter的盒子
class ZHUniListAdapterBox: NSObject {
    var adapter: ListAdapter?
    init(adapter: ListAdapter) {
        self.adapter = adapter
        super.init()
    }
}

// 基于IG封装ZHListKit的API层
class ZHUniListKitApi: NSObject {
    let listAdapterUpdater: ListAdapterUpdater
    let viewController: UIViewController
    let workingRangeSize: NSInteger
    let collectionView: UICollectionView
    
    init(viewController: UIViewController, workingRangeSize: NSInteger, collectionView: UICollectionView, listAdapterUpdater: ListAdapterUpdater) {
        self.viewController = viewController
        self.workingRangeSize = workingRangeSize
        self.collectionView = collectionView
        self.listAdapterUpdater = listAdapterUpdater
    }
    
    lazy var adapter: ListAdapter =  {
        let adapter = ListAdapter(updater: listAdapterUpdater, viewController: viewController, workingRangeSize: workingRangeSize)
        adapter.collectionView = collectionView
        return adapter
    }()
}

class ZHUniSectionController: ListSectionController {

}

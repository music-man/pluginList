//
//  ZHUniPluginManager.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/7/13.
//

import Foundation

class ZHUniPluginManager: NSObject {
    // 添加通知机制
    let noticeCenter = ZHUniNoticeCenter(domain: "")
      // 所有插件
    var allPlugins = [UniPluginReceiver]()
    // 容器
    private weak var container : ZHUnilistContainer?
    
    init(_ container: ZHUnilistContainer) {
        self.container = container
    }

    override init() {
        super.init()
    }
    
    func addPlugins(plugins: [ZHUniPluginProtocol]) -> Bool {
        var succeed = true
        for item in plugins {
            if addPlugin(key: item.pluginIdentifier(), plugin: item) {
                succeed = false
            }
        }
        return succeed
    }
    
    func addPlugin(key: String, plugin: ZHUniPluginProtocol) -> Bool {
        for item in allPlugins where item.pluginName == key {
            debugPrint("注册插件失败,已有相同pluginIdentifier的插件注册,请更换pluginIdentifier:" + item.pluginName)
            return false
        }
        let receiver = UniPluginReceiver(pluginName: key, receiver: plugin)
        allPlugins.append(receiver)
        return true
    }
    
    func removePlugin(key: String, plugin: ZHUniPluginProtocol) {
        allPlugins.removeAll(where: {key == $0.pluginName})
    }
}

// 容器协议分发
extension ZHUniPluginManager {
    func viewDidLoad() {
        allPlugins.forEach {
            if let lifeCirclePlugin = $0.receiver as? ZHUniPluginLifeCircleProtocol {
                lifeCirclePlugin.containerViewDidLoad?()
            }
        }
    }
    
    public func viewWillAppear(_ animated: Bool) {
        allPlugins.forEach {
            if let lifeCirclePlugin = $0.receiver as? ZHUniPluginLifeCircleProtocol {
                lifeCirclePlugin.containerViewWillAppear?(animated)
            }
        }
    }

    public func viewDidAppear(_ animated: Bool) {
        allPlugins.forEach {
            if let lifeCirclePlugin = $0.receiver as? ZHUniPluginLifeCircleProtocol {
                lifeCirclePlugin.containerViewDidAppear?(animated)
            }
        }
    }

    public func viewWillDisappear(_ animated: Bool) {
        allPlugins.forEach {
            if let lifeCirclePlugin = $0.receiver as? ZHUniPluginLifeCircleProtocol {
                lifeCirclePlugin.containerViewWillDisappear?(animated)
            }
        }
    }

    public func viewDidDisappear(_ animated: Bool) {
        allPlugins.forEach {
            if let lifeCirclePlugin = $0.receiver as? ZHUniPluginLifeCircleProtocol {
                lifeCirclePlugin.containerViewDidDisappear?(animated)
            }
        }
    }
}

protocol ZHUniPluginProtocol: NSObject {
    func pluginIdentifier() -> String
}

// 插件key,value存储
public class UniPluginReceiver: NSObject {
    let pluginName: String
    weak var receiver: ZHUniPluginProtocol? //  插件弱引用
    
    init(pluginName: String, receiver: ZHUniPluginProtocol) {
        self.pluginName = pluginName
        self.receiver = receiver
    }
}

//
//  ZHUniNoticeCenter.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/7/13.
//

import Foundation

// 一对多消息协议
protocol ZHUniNoticeCenterProtocol: NSObject {
    func receiveMessage(name: String, param: [String: Any]) // 事件接收
    func receiveMessages() -> [String] // 所有关注的事件
}

// 线程
public enum ThreadMode {
    case mainThread
    case subThread
}

// 优先级
public enum ZHUniNoticePriority {
    case value(Int)

    public static var low: ZHUniNoticePriority {
        return .value(10)
    }

    public static var normal: ZHUniNoticePriority {
        return .value(20)
    }

    public static var high: ZHUniNoticePriority {
        return .value(30)
    }
}

// 一对一消息订阅者
public class NoticeOneToOneReceiver: NSObject {
    let eventHandler: ([String: Any]) -> Void
    let noticeName: String
    let threadMode: ThreadMode
    let priority: ZHUniNoticePriority

    init(threadMode: ThreadMode, priority: ZHUniNoticePriority = .normal, noticeName: String, eventHandler: @escaping ([String: Any]) -> Void) {
        self.threadMode = threadMode
        self.priority = priority
        self.noticeName = noticeName
        self.eventHandler = eventHandler
    }
}

// 一对多消息订阅者
public class NoticeOneToSomeReceiver: NSObject {
    let receiver: ZHUniNoticeCenterProtocol
    init(receiver: ZHUniNoticeCenterProtocol) {
        self.receiver = receiver
    }
}

// 自动移除监听bag
public class UniOneToOneDisposeBag {
    let receiver: NoticeOneToOneReceiver
    let noticeCenter: ZHUniNoticeCenter

    init(receiver: NoticeOneToOneReceiver, noticeCenter: ZHUniNoticeCenter) {
        self.receiver = receiver
        self.noticeCenter = noticeCenter
    }

    deinit {
        objc_sync_enter(self)
        defer {
            objc_sync_exit(self)
        }
        noticeCenter.resignOneToOneReceiver(receiver: receiver)
    }
}

// 自动移除监听bag
public class UniOneToSomeDisposeBag {
    let receiver: ZHUniNoticeCenterProtocol
    let noticeCenter: ZHUniNoticeCenter
    init(receiver: ZHUniNoticeCenterProtocol, noticeCenter: ZHUniNoticeCenter) {
        self.receiver = receiver
        self.noticeCenter = noticeCenter
    }

    deinit {
        objc_sync_enter(self)
        defer {
            objc_sync_exit(self)
        }
        noticeCenter.resignOnetoSomeReceiver(receiver: receiver)
    }
}

// 消息中心
public class ZHUniNoticeCenter: NSObject {
    var allOneToSomeReceivers = [ZHUniNoticeCenterProtocol]()
    // 一个key对应一个receiver
    var allOneToOneNoticeReceivers = [String: [NoticeOneToOneReceiver]]()

    public let domain: String
    
    static let shared = ZHUniNoticeCenter(domain: "ZHUniNoticeCenter.default.domain")
    
    public init(domain: String) {
        self.domain = domain
    }
    
    // 注册消息
    func registerNotice(noticeName: String, eventHandler: @escaping ([String: Any]) -> Void) -> UniOneToOneDisposeBag {
        return registerNotice(noticeName: noticeName, priority: .normal, eventHandler: eventHandler)
    }
    
    func registerNotice(noticeName: String, priority: ZHUniNoticePriority, eventHandler: @escaping ([String: Any]) -> Void) -> UniOneToOneDisposeBag {
        return registerNotice(noticeName: noticeName, priority: priority, threadMode: .mainThread, eventHandler: eventHandler)
    }
    
    func registerNotice(noticeName: String, priority: ZHUniNoticePriority, threadMode: ThreadMode, eventHandler: @escaping ([String: Any]) -> Void) -> UniOneToOneDisposeBag {
        let receiver = NoticeOneToOneReceiver(threadMode: threadMode, noticeName: noticeName, eventHandler: eventHandler)
        
        if var recievers = allOneToOneNoticeReceivers[noticeName] {
            recievers.append(receiver)
            allOneToOneNoticeReceivers[noticeName] = recievers
        } else {
            var recievers = [NoticeOneToOneReceiver]()
            recievers.append(receiver)
            allOneToOneNoticeReceivers[noticeName] = recievers
        }
        
        return UniOneToOneDisposeBag(receiver: receiver, noticeCenter: self)
    }

    // 发送全体消息
    func postNotice(name: String, param: [String: Any]) {
        postOneToOneNotice(noticeName: name, param: param)
        postOneToSomeNotice(noticeName: name, param: param)
    }
    
    // 发送一对一消息
    func postOneToOneNotice(noticeName: String, param: [String: Any]) {
        if let recievers = allOneToOneNoticeReceivers[noticeName] {
            let sortedAllReceivers = recievers.sorted { (left, right) -> Bool in
                switch (left.priority, right.priority) {
                case (.value(let leftValue), .value(let rightValue)):
                    return leftValue < rightValue
                }
            }
             
            for receiver in sortedAllReceivers {
                if receiver.threadMode == .mainThread {
                    DispatchQueue.main.async {
                        receiver.eventHandler(param)
                    }
                } else if receiver.threadMode == .subThread {
                    DispatchQueue.global().async {
                        receiver.eventHandler(param)
                    }
                }
            }
        } else {
            print("没有接收者")
        }
    }

    // 移除接收消息
    func resignOneToOneReceiver(receiver: NoticeOneToOneReceiver) {
        self.allOneToOneNoticeReceivers[receiver.noticeName]?.removeAll(where: {$0 == receiver})
    }
}

// 一对多
extension ZHUniNoticeCenter {
    // 注册接收消息通知
    func becomeReceiver(receiver: ZHUniNoticeCenterProtocol) -> UniOneToSomeDisposeBag {
        self.allOneToSomeReceivers.append(receiver)
        return UniOneToSomeDisposeBag(receiver: receiver, noticeCenter: self)
    }
    
    // 移除接收消息
    func resignOnetoSomeReceiver(receiver: ZHUniNoticeCenterProtocol) {
        self.allOneToSomeReceivers.removeAll(where: {$0 == receiver})
    }

    func postOneToSomeNotice(noticeName: String, param: [String: Any]) {
        for receiver in allOneToSomeReceivers where receiver.receiveMessages().contains(noticeName) {
            DispatchQueue.main.async {
                receiver.receiveMessage(name: noticeName, param: param)
            }
        }
    }
    
    // 事件回放待完善
    func noticePlayback() {
        
    }
}

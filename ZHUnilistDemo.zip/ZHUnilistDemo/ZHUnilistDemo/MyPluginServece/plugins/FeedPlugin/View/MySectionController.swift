//
//  MySectionController.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/7/10.
//

import Foundation
import UIKit


class MyCell: UICollectionViewCell {
    
}

class MySectionController: ZHUniSectionController {
    override func numberOfItems() -> Int {
        return 1
    }
    
    override func sizeForItem(at index: Int) -> CGSize {
        return CGSize(width: 300, height: 30)
    }
    override func cellForItem(at index: Int) -> UICollectionViewCell {
        guard let cell = collectionContext?.dequeueReusableCell(of: MyCell.self, for: self, at: 0) as? MyCell else {
            return UICollectionViewCell()
        }
        cell.backgroundColor = UIColor.blue
        return cell
    }
    
    override func didSelectItem(at index: Int) {
        print("didSelectItem")
    }
}

//
//  ViewController.swift
//  ZHUnilistDemo
//
//  Created by liuweimin on 2023/6/27.
//

import UIKit

class MyCardOneModel: NSObject, ZHUniListDiffable {
    var name: String?
    
    func zhdiffIdentifier() -> NSObjectProtocol {
        return self
    }

    func zhisEqualToDiffableObject(object: ZHUniListDiffable) -> Bool {
        return (zhdiffIdentifier() as AnyObject).isEqual(object.zhdiffIdentifier())
    }
}

class ViewController: UIViewController, ZHUniNoticeCenterProtocol, ZHUniListAdapterDelegate, ZHUniPluginProtocol {
    func pluginIdentifier() -> String {
        return "ViewControllerIdentifier"
    }
    
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, willDisplay object: Any, at index: Int) {
        
    }
    
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, didEndDisplaying object: Any, at index: Int) {
        
    }
    
    var container: ZHUnilistContainer?
    var dataArray = [MyCardOneModel]()
    var adapter: ZHUniListAdapterBox?
    var disposeBags: [Any]? = [Any]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        createList()
        setUI()
        testNoitceCenter()
    }
    
    func testNoitceCenter() {
        let disposeBag1 = ZHUniNoticeCenter.shared.registerNotice(noticeName: "hello", priority: .normal, threadMode: .mainThread) { param in
            print(param.description)
        }
        
        
        let disposeBag2 = ZHUniNoticeCenter.shared.registerNotice(noticeName: "hello", priority: .normal, threadMode: .mainThread) { param in
            print(param.description)
        }
        
        let disposeBag3 = ZHUniNoticeCenter.shared.becomeReceiver(receiver: self)
        
        disposeBags?.append(disposeBag1)
        disposeBags?.append(disposeBag2)
        disposeBags?.append(disposeBag3)
        
        DispatchQueue.main.asyncAfter(deadline: .now()+3) {
            ZHUniNoticeCenter.shared.postNotice(name: "hello", param: ["key":"value"])
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now()+5) {
            self.disposeBags = nil
        }
    }
    
    func receiveMessage(name: String, param: [String: Any]) {
        print(name + param.description)
    }
    
    func receiveMessages() -> [String] {
        return ["hello"]
    }
    
    func setData() {
        for i in 0...10 {
            let stringname = "card" + i.description
            let model = MyCardOneModel()
            model.name = stringname
            dataArray.append(model)
        }
    }
    
    func createList() {
        setData()
        // 创建列表
        let config = ZHUnilistContainerConfig(dataSource: self, delegate: self)
        let listVC = ZHUnilistContainerFactory.createUnilistContainer(config: config)
        container = listVC
        // 设置通用能力
        var commonAblity = UniCommonAblity()
        commonAblity.gfAblity = true
        listVC.commonAblity = commonAblity
        // 添加插件
        if listVC.addPlugin(key: "myKey1", plugin: self) {
            print("成功添加")
        }

        // 设置UI
        listVC.view.frame = CGRect(x: 0, y: 200, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - 200)
        listVC.view.backgroundColor = UIColor.blue
        // 使用列表
        view.addSubview(listVC.view)
        self.addChild(listVC)
    }
    
    func setUI() {
        let button = UIButton(frame: CGRect(x: 100, y: 100, width: 200, height: 50))
        button.backgroundColor = .blue
        button.setTitle("控制容器刷新", for: .normal)
        button.addTarget(self, action: #selector(buttonCLick), for: .touchUpInside)
        self.view.addSubview(button)
    }
    
    @objc func buttonCLick() {
//        dataArray = ["newcard1","newcard2","newcard3","newcard4","newcard5","newcard6"]
        container?.reloadList()
        
        if let adpt = self.adapter?.adapter?.visibleObjects() {
            for obj in adpt {
                print((obj as AnyObject).description)
            }
        }
    }
}


extension ViewController: ZHUniListAdapterDataSource {
    func objects(for listAdapter: ZHUniListAdapterBox) -> [ZHUniListDiffable] {
        let data = dataArray
        adapter = listAdapter
        return data
    }
    
    func listAdapter(_ listAdapter: ZHUniListAdapterBox, sectionControllerFor object: Any) -> ZHUniSectionController {
        return MySectionController()
    }
    
    func emptyView(for listAdapter: ZHUniListAdapterBox) -> UIView? {
        return UIView()
    }
}

extension ViewController: ZHUniPluginLifeCircleProtocol {
    func containerViewDidLoad() {
        print("业务接入插件化列表UNilist成功")
    }
    
    func containerViewWillAppear(_ animated: Bool) {
//        print("容器viewWillAppear")
    }
}
